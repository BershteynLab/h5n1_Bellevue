H5N1 Risk Map - Interactive Visualization
==========================================

INSTRUCTIONS FOR VIEWING:
-------------------------
1. Extract this zip file to any location on your computer
2. Open 'nyc_risk_map.html' in any web browser:
   - Double-click the file, OR
   - Right-click → Open With → Choose your browser
3. Make sure you have an internet connection (required for map libraries)
4. The interactive map will load automatically

INTERACTIVE FEATURES:
---------------------
- Click on any zip code to see detailed risk information
- Zoom in/out using mouse wheel or controls
- Pan by clicking and dragging
- Color coding shows risk levels:
  * Green/Yellow: Low to Medium risk
  * Orange: High risk
  * Red: Very High risk

REQUIREMENTS:
-------------
- Any modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection (for loading map libraries)
- No additional software needed

TROUBLESHOOTING:
-----------------
- If the map doesn't load:
  * Try a different web browser
  * Make sure you have internet connection
  * Check that pop-ups aren't blocked
  * Try refreshing the page (F5)

- If you see a blank page:
  * Wait a few seconds for libraries to load
  * Check browser console for errors (F12 → Console)
  * Try opening in a different browser

FILE INFORMATION:
------------------
- Interactive Map: nyc_risk_map.html (6.7 MB)
- Static Map: nyc_risk_map.png (if included)
- All geographic data is embedded in the HTML file
- No additional data files needed

CONTACT:
--------
For questions about the risk map or methodology, please refer to:
- docs/RISK_METHODOLOGY.md - Methodology documentation
- docs/RISK_FACTORS_EXPLAINED.md - Detailed factor explanations

Generated: 2025-12-06 11:10:32
